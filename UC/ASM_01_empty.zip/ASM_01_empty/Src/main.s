.syntax unified
.cpu cortex-m3
.fpu softvfp
.thumb

.include "stm32f103xx.h"

.section .text
.global main
main:



Loop:


	B Loop
