.syntax unified
.cpu cortex-m3
.fpu softvfp
.thumb

.include "stm32f103xx.h"

.section .text
.global main
.type main, %function
main:



Loop:


	B Loop
